<?php
/**
 * One-time installer. Creates the database tables, the first admin user and includes/config.php.
 * DELETE the /install folder from the server when finished.
 */
require_once __DIR__ . '/../includes/functions.php';
header('X-Robots-Tag: noindex, nofollow');
header('Cache-Control: no-store');

$lock = __DIR__ . '/.lock';
$configFile = ROOT_DIR . '/includes/config.php';
$errors = [];
$done = false;

// Refuse to run again once installed.
if (is_file($lock)) {
    http_response_code(403);
    exit('Already installed. Delete the /install folder from your server.');
}

$guessBase = rtrim(str_replace('\\', '/', dirname(dirname($_SERVER['SCRIPT_NAME'] ?? '/install/install.php'))), '/');
$v = [
    'db_host' => 'localhost', 'db_name' => '', 'db_user' => '', 'db_pass' => '',
    'site_url' => ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https://' : 'http://') . ($_SERVER['HTTP_HOST'] ?? 'localhost') . $guessBase,
    'base_path' => $guessBase === '/' ? '' : $guessBase,
    'mail_to' => 'admin@mcattorneys.co.zw', 'mail_from' => '',
    'admin_name' => '', 'admin_email' => '',
];
$withSamples = true;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // No session token check here on purpose: this one-time page is already open to anyone until it is used and
    // locked, and a session that expires while you set up the database in cPanel must not block the install.
    foreach ($v as $k => $_) { $v[$k] = trim((string) ($_POST[$k] ?? $v[$k])); }
    $pass = (string) ($_POST['admin_pass'] ?? '');
    $withSamples = !empty($_POST['samples']);

    if ($v['db_name'] === '' || $v['db_user'] === '') { $errors[] = 'Enter the database name and user created in cPanel → MySQL® Databases.'; }
    if ($v['admin_name'] === '') { $errors[] = 'Enter the administrator name.'; }
    if (!filter_var($v['admin_email'], FILTER_VALIDATE_EMAIL)) { $errors[] = 'Enter a valid administrator email.'; }
    if (strlen($pass) < 10) { $errors[] = 'The administrator password must be at least 10 characters.'; }
    if ($v['mail_from'] !== '' && !filter_var($v['mail_from'], FILTER_VALIDATE_EMAIL)) { $errors[] = 'The "send from" email is not valid.'; }

    if (!$errors) {
        try {
            $pdo = new PDO("mysql:host={$v['db_host']};dbname={$v['db_name']};charset=utf8mb4", $v['db_user'], $v['db_pass'], [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
            $sql = file_get_contents(ROOT_DIR . '/sql/schema.sql');
            foreach (array_filter(array_map('trim', preg_split('/;\s*[\r\n]+/', $sql))) as $stmt) {
                if (!preg_match('/^--/', $stmt) || preg_match('/CREATE/i', $stmt)) {
                    $pdo->exec(preg_replace('/^--.*$/m', '', $stmt));
                }
            }
            $exists = (int) $pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
            if ($exists > 0) {
                $errors[] = 'This database already has an administrator. Installation stopped to protect existing data.';
            } else {
                $pdo->prepare('INSERT INTO users (name, email, password_hash) VALUES (?,?,?)')
                    ->execute([$v['admin_name'], strtolower($v['admin_email']), password_hash($pass, PASSWORD_DEFAULT)]);

                if ($withSamples) {
                    $covers = [
                        'what-to-know-before-transferring-property' => 'conveyancing.jpg', 'administering-a-deceased-estate' => 'estates.jpg',
                        'employer-duties-when-ending-employment' => 'labour.jpg', 'choosing-a-business-structure' => 'commercial.jpg',
                        'your-rights-when-arrested' => 'litigation.jpg', 'understanding-mining-title' => 'mining.jpg',
                        'mc-attorneys-opens-in-eastlea' => 'news.jpg',
                    ];
                    @mkdir(ROOT_DIR . '/uploads', 0755, true);
                    $ins = $pdo->prepare('INSERT IGNORE INTO posts (title, slug, excerpt, content, cover_image, category, author, status, published_at) VALUES (?,?,?,?,?,?,?,?,?)');
                    foreach (require __DIR__ . '/sample-posts.php' as [$slug, $cat, $title, $author, $date, $excerpt, $html]) {
                        $cover = $covers[$slug] ?? null;
                        $src = __DIR__ . '/sample-covers/' . $cover;
                        if ($cover && is_file($src)) { @copy($src, ROOT_DIR . '/uploads/' . $cover); @chmod(ROOT_DIR . '/uploads/' . $cover, 0644); } else { $cover = null; }
                        $ins->execute([$title, $slug, $excerpt, $html, $cover, $cat, $author, 'published', $date . ' 09:00:00']);
                    }
                }

                $cfg = [
                    'db_host' => $v['db_host'], 'db_name' => $v['db_name'], 'db_user' => $v['db_user'], 'db_pass' => $v['db_pass'],
                    'base_path' => $v['base_path'], 'site_url' => rtrim($v['site_url'], '/'),
                    'mail_to' => $v['mail_to'], 'mail_from' => $v['mail_from'] !== '' ? $v['mail_from'] : 'no-reply@' . preg_replace('/^www\./', '', (string) ($_SERVER['HTTP_HOST'] ?? 'localhost')),
                ];
                $php = "<?php\n// Generated by install.php — do not commit this file.\nreturn " . var_export($cfg, true) . ";\n";
                if (file_put_contents($configFile, $php, LOCK_EX) === false) {
                    $errors[] = 'Could not write includes/config.php. Make the includes folder writable (755/775) and try again.';
                } else {
                    @chmod($configFile, 0640);
                    @file_put_contents($lock, date('c'));
                    @mkdir(ROOT_DIR . '/uploads', 0755, true);
                    $done = true;
                }
            }
        } catch (Throwable $ex) {
            $errors[] = 'Database error: ' . $ex->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex">
<title>Install — MC Attorneys CMS</title>
<style>
body{font:16px/1.55 system-ui,sans-serif;background:#0B1F3A;margin:0;padding:32px 16px;color:#2A3342}
.card{max-width:640px;margin:0 auto;background:#fff;border-radius:10px;padding:32px}
h1{margin:0 0 4px;color:#0B1F3A}h2{margin:28px 0 8px;font-size:15px;text-transform:uppercase;letter-spacing:.08em;color:#C99A2E}
label{display:block;margin:12px 0 4px;font-weight:600;font-size:14px}input{width:100%;padding:10px 12px;border:1px solid #C9C4B8;border-radius:6px;font:inherit}
button{margin-top:24px;background:#C99A2E;border:0;border-radius:6px;padding:12px 22px;font-weight:700;color:#07152A;cursor:pointer}
.err{background:#FBEAEA;border:1px solid #F0C6C6;color:#8A1F1F;padding:12px 16px;border-radius:6px;margin:16px 0}
.ok{background:#E8F5EC;border:1px solid #BFE0CA;color:#1E5B34;padding:16px;border-radius:6px}small{color:#7A8494}
</style></head><body><div class="card">
<h1>MC Attorneys — CMS installer</h1>
<p><small>Run once. Create the MySQL database and user first in cPanel → MySQL® Databases.</small></p>
<?php if ($done): ?>
  <div class="ok"><strong>Installation complete.</strong>
    <ol>
      <li><strong>Delete the <code>/install</code> folder</strong> from the server (cPanel → File Manager).</li>
      <li><a href="<?= e(url('admin/login.php')) ?>">Log in to the Content Manager</a>.</li>
    </ol></div>
<?php else: ?>
  <?php if ($errors): ?><div class="err"><?php foreach ($errors as $er): ?><?= e($er) ?><br><?php endforeach; ?></div><?php endif; ?>
  <form method="post">
    <h2>Database</h2>
    <label>Host</label><input name="db_host" value="<?= e($v['db_host']) ?>" required>
    <label>Database name</label><input name="db_name" value="<?= e($v['db_name']) ?>" placeholder="cpaneluser_mcattorneys" required>
    <label>Database user</label><input name="db_user" value="<?= e($v['db_user']) ?>" required>
    <label>Database password</label><input type="password" name="db_pass" autocomplete="new-password">
    <h2>Site</h2>
    <label>Site URL <small>(no trailing slash)</small></label><input name="site_url" value="<?= e($v['site_url']) ?>" required>
    <label>Install folder <small>(blank if at the domain root)</small></label><input name="base_path" value="<?= e($v['base_path']) ?>">
    <label>Send contact enquiries to</label><input type="email" name="mail_to" value="<?= e($v['mail_to']) ?>" required>
    <label>Send enquiries from <small>(an address on your domain, e.g. no-reply@yourdomain.co.zw)</small></label><input type="email" name="mail_from" value="<?= e($v['mail_from']) ?>">
    <h2>Administrator</h2>
    <label>Name</label><input name="admin_name" value="<?= e($v['admin_name']) ?>" required>
    <label>Email (used to log in)</label><input type="email" name="admin_email" value="<?= e($v['admin_email']) ?>" required>
    <label>Password <small>(min. 10 characters)</small></label><input type="password" name="admin_pass" minlength="10" required autocomplete="new-password">
    <h2>Sample content</h2>
    <label style="font-weight:400"><input type="checkbox" name="samples" value="1" style="width:auto" <?= $withSamples ? 'checked' : '' ?>> Add the 7 sample blog articles (with pictures) so the Blog page is not empty. You can edit or delete them later.</label>
    <button type="submit">Install</button>
  </form>
<?php endif; ?>
</div></body></html>
